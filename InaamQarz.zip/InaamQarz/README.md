# Inaam Qarz

Logon se udhar lene aur dene ka hisaab rakhne wali Android app (Kotlin + Jetpack Compose + Room).

## Chalane ka tareeqa
1. Android Studio (Koala ya naya) install karen.
2. `File > Open` se is `InaamQarz` folder ko kholen.
3. Gradle sync complete hone den (internet chahiye).
4. Phone ya emulator select karke **Run** dabayen.

APK banane ke liye: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

## Features
- Log (naam + phone) add karna
- Udhar Diya / Udhar Liya / Wapas Mila / Wapas Diya likhna (raqam + note)
- Har shakhs ka hisaab aur kul "Milne Hain" / "Dene Hain"
- Tareekh-war lain dain, delete karne ki sahulat
- SMS se yaad dahani
- Data phone me offline mehfooz (Room database)
