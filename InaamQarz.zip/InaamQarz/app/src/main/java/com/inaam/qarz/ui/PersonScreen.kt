package com.inaam.qarz.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.inaam.qarz.data.Entry
import com.inaam.qarz.data.EntryType
import com.inaam.qarz.data.Person

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonScreen(
    person: Person,
    entries: List<Entry>,
    onBack: () -> Unit,
    onAddEntry: (amount: Double, type: EntryType, note: String) -> Unit,
    onDeleteEntry: (Entry) -> Unit,
    onDeletePerson: () -> Unit
) {
    val context = LocalContext.current
    var dialogType by remember { mutableStateOf<EntryType?>(null) }
    var confirmDeletePerson by remember { mutableStateOf(false) }
    var entryToDelete by remember { mutableStateOf<Entry?>(null) }

    val balance = entries.sumOf { it.signed() }
    val color = when {
        balance > 0 -> GreenOk
        balance < 0 -> RedDue
        else -> MaterialTheme.colorScheme.primary
    }
    val caption = when {
        balance > 0 -> "${person.name} ne aap ko dena hai"
        balance < 0 -> "Aap ne ${person.name} ko dena hai"
        else -> "Hisaab barabar hai"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(person.name, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Wapas")
                    }
                },
                actions = {
                    IconButton(onClick = { confirmDeletePerson = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Shakhs hatayen")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = color)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(caption, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                    Text(
                        money(balance),
                        color = Color.White,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { dialogType = EntryType.LEND },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenOk)
                ) { Text("Udhar Diya") }
                Button(
                    onClick = { dialogType = EntryType.BORROW },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = RedDue)
                ) { Text("Udhar Liya") }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { dialogType = EntryType.RECEIVED },
                    modifier = Modifier.weight(1f)
                ) { Text("Wapas Mila") }
                OutlinedButton(
                    onClick = { dialogType = EntryType.PAID },
                    modifier = Modifier.weight(1f)
                ) { Text("Wapas Diya") }
            }

            if (balance > 0 && person.phone.isNotBlank()) {
                TextButton(
                    onClick = { sendReminder(context, person, balance) },
                    modifier = Modifier.padding(top = 4.dp)
                ) { Text("SMS se yaad dahani bhejen") }
            }

            Text(
                "Tareekh-war hisaab",
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
            )

            if (entries.isEmpty()) {
                Text(
                    "Abhi koi lain dain nahi likha gaya.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(entries, key = { it.id }) { e ->
                        EntryRow(e) { entryToDelete = e }
                    }
                }
            }
        }
    }

    dialogType?.let { type ->
        EntryDialog(
            type = type,
            personName = person.name,
            onDismiss = { dialogType = null },
            onSave = { amount, note ->
                dialogType = null
                onAddEntry(amount, type, note)
            }
        )
    }

    if (confirmDeletePerson) {
        AlertDialog(
            onDismissRequest = { confirmDeletePerson = false },
            title = { Text("${person.name} hatayen?") },
            text = { Text("Is shakhs ka saara hisaab hamesha ke liye khatam ho jayega.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDeletePerson = false
                    onDeletePerson()
                }) { Text("Hatayen", color = RedDue) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeletePerson = false }) { Text("Mansookh") }
            }
        )
    }

    entryToDelete?.let { e ->
        AlertDialog(
            onDismissRequest = { entryToDelete = null },
            title = { Text("Ye lain dain hatayen?") },
            text = { Text("${e.entryType.label}: ${money(e.amount)}") },
            confirmButton = {
                TextButton(onClick = {
                    entryToDelete = null
                    onDeleteEntry(e)
                }) { Text("Hatayen", color = RedDue) }
            },
            dismissButton = {
                TextButton(onClick = { entryToDelete = null }) { Text("Mansookh") }
            }
        )
    }
}

@Composable
private fun EntryRow(e: Entry, onLongDelete: () -> Unit) {
    val positive = e.entryType.sign > 0
    val color = if (positive) GreenOk else RedDue

    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(e.entryType.label, fontWeight = FontWeight.SemiBold)
                if (e.note.isNotBlank()) Text(e.note, fontSize = 13.sp)
                Text(
                    formatDate(e.date),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                (if (positive) "+ " else "- ") + money(e.amount),
                color = color,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onLongDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Hatayen")
            }
        }
    }
}

private fun sendReminder(context: Context, person: Person, balance: Double) {
    val msg = "Assalam o Alaikum ${person.name}, yaad dahani: aap ne mujhe ${money(balance)} dene hain. Shukriya."
    try {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${person.phone}")).apply {
            putExtra("sms_body", msg)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "SMS app nahi mili", Toast.LENGTH_SHORT).show()
    }
}
