package com.inaam.qarz.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.inaam.qarz.data.PersonSummary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    summaries: List<PersonSummary>,
    onOpen: (Long) -> Unit,
    onAddPerson: (name: String, phone: String) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }

    val toReceive = summaries.filter { it.balance > 0 }.sumOf { it.balance }
    val toPay = summaries.filter { it.balance < 0 }.sumOf { -it.balance }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Inaam Qarz", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Naya Shakhs") }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TotalCard("Mujhe Milne Hain", toReceive, GreenOk, Modifier.weight(1f))
                TotalCard("Mujhe Dene Hain", toPay, RedDue, Modifier.weight(1f))
            }

            if (summaries.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Abhi koi hisaab nahi.\nNeeche \"Naya Shakhs\" dabayen\naur udhar likhna shuru karen.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(summaries, key = { it.person.id }) { s ->
                        PersonRow(s) { onOpen(s.person.id) }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddPersonDialog(
            onDismiss = { showAdd = false },
            onSave = { name, phone ->
                showAdd = false
                onAddPerson(name, phone)
            }
        )
    }
}

@Composable
private fun TotalCard(title: String, amount: Double, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
            Text(
                money(amount),
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PersonRow(s: PersonSummary, onClick: () -> Unit) {
    val color = when {
        s.balance > 0 -> GreenOk
        s.balance < 0 -> RedDue
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val caption = when {
        s.balance > 0 -> "Aap ko milna hai"
        s.balance < 0 -> "Aap ne dena hai"
        else -> "Hisaab barabar"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    s.person.name.firstOrNull()?.uppercase() ?: "?",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.person.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                if (s.person.phone.isNotBlank()) {
                    Text(
                        s.person.phone,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(money(s.balance), color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(caption, color = color, fontSize = 11.sp)
            }
        }
    }
}
