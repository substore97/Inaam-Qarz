package com.inaam.qarz.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.ui.unit.dp
import com.inaam.qarz.data.EntryType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun money(value: Double): String {
    val v = kotlin.math.abs(value)
    val text = if (v % 1.0 == 0.0) "%,.0f".format(v) else "%,.2f".format(v)
    return "Rs $text"
}

fun formatDate(millis: Long): String =
    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(millis))

@Composable
fun AddPersonDialog(onDismiss: () -> Unit, onSave: (name: String, phone: String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Naya Shakhs") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Naam") },
                    singleLine = true
                )
                Spacer(Modifier_h8)
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone (zaroori nahi)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(name, phone) },
                enabled = name.isNotBlank()
            ) { Text("Mehfooz Karen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Mansookh") } }
    )
}

@Composable
fun EntryDialog(
    type: EntryType,
    personName: String,
    onDismiss: () -> Unit,
    onSave: (amount: Double, note: String) -> Unit
) {
    var amountText by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    val amount = amountText.toDoubleOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${type.label} - $personName") },
        text = {
            Column {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Raqam (Rs)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Spacer(Modifier_h8)
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note (zaroori nahi)") }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(amount ?: 0.0, note) },
                enabled = amount != null && amount > 0
            ) { Text("Mehfooz Karen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Mansookh") } }
    )
}

private val Modifier_h8 = androidx.compose.ui.Modifier.height(8.dp)
