package com.inaam.qarz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.produceState
import com.inaam.qarz.data.Entry
import com.inaam.qarz.data.Person
import com.inaam.qarz.ui.HomeScreen
import com.inaam.qarz.ui.InaamQarzTheme
import com.inaam.qarz.ui.PersonScreen

class MainActivity : ComponentActivity() {
    private val vm: QarzViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InaamQarzTheme {
                QarzApp(vm)
            }
        }
    }
}

@Composable
private fun QarzApp(vm: QarzViewModel) {
    var selectedId by rememberSaveable { mutableStateOf<Long?>(null) }
    val summaries by vm.summaries.collectAsState()

    val id = selectedId
    if (id == null) {
        HomeScreen(
            summaries = summaries,
            onOpen = { selectedId = it },
            onAddPerson = { name, phone -> vm.addPerson(name, phone) { newId -> selectedId = newId } }
        )
    } else {
        BackHandler { selectedId = null }

        val person by produceState<Person?>(initialValue = null, id) {
            vm.person(id).collect { value = it }
        }
        val entries by produceState<List<Entry>>(initialValue = emptyList(), id) {
            vm.entries(id).collect { value = it }
        }

        // Shakhs delete ho gaya ho to wapas home
        LaunchedEffect(person, summaries) {
            if (person == null && summaries.none { it.person.id == id } && summaries.isNotEmpty()) {
                selectedId = null
            }
        }

        person?.let { p ->
            PersonScreen(
                person = p,
                entries = entries,
                onBack = { selectedId = null },
                onAddEntry = { amount, type, note -> vm.addEntry(p.id, amount, type, note) },
                onDeleteEntry = { vm.deleteEntry(it) },
                onDeletePerson = {
                    vm.deletePerson(p.id)
                    selectedId = null
                }
            )
        }
    }
}
