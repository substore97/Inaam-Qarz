package com.inaam.qarz.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Hisaab ki 4 qismen.
 * sign > 0  => samne wale ne mujhe dena hai (balance barhta hai)
 * sign < 0  => maine samne wale ko dena hai (balance ghat'ta hai)
 */
enum class EntryType(val label: String, val sign: Int) {
    LEND("Udhar Diya", 1),
    BORROW("Udhar Liya", -1),
    RECEIVED("Wapas Mila", -1),
    PAID("Wapas Diya", 1)
}

@Entity(tableName = "people")
data class Person(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = ""
)

@Entity(
    tableName = "entries",
    foreignKeys = [
        ForeignKey(
            entity = Person::class,
            parentColumns = ["id"],
            childColumns = ["personId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("personId")]
)
data class Entry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val amount: Double,
    val type: String,
    val note: String = "",
    val date: Long = System.currentTimeMillis()
) {
    val entryType: EntryType get() = EntryType.valueOf(type)
    fun signed(): Double = amount * entryType.sign
}

data class PersonSummary(
    val person: Person,
    /** > 0: unhon ne mujhe dena hai, < 0: maine unhen dena hai */
    val balance: Double
)
