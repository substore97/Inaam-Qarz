package com.inaam.qarz.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface QarzDao {
    @Query("SELECT * FROM people ORDER BY name COLLATE NOCASE")
    fun people(): Flow<List<Person>>

    @Query("SELECT * FROM people WHERE id = :id")
    fun person(id: Long): Flow<Person?>

    @Query("SELECT * FROM entries")
    fun allEntries(): Flow<List<Entry>>

    @Query("SELECT * FROM entries WHERE personId = :id ORDER BY date DESC, id DESC")
    fun entriesFor(id: Long): Flow<List<Entry>>

    @Insert
    suspend fun insertPerson(person: Person): Long

    @Insert
    suspend fun insertEntry(entry: Entry)

    @Delete
    suspend fun deleteEntry(entry: Entry)

    @Query("DELETE FROM people WHERE id = :id")
    suspend fun deletePerson(id: Long)
}

@Database(entities = [Person::class, Entry::class], version = 1, exportSchema = false)
abstract class QarzDb : RoomDatabase() {
    abstract fun dao(): QarzDao

    companion object {
        @Volatile private var instance: QarzDb? = null

        fun get(context: Context): QarzDb =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    QarzDb::class.java,
                    "inaam_qarz.db"
                ).build().also { instance = it }
            }
    }
}
