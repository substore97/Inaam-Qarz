package com.inaam.qarz

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.inaam.qarz.data.Entry
import com.inaam.qarz.data.EntryType
import com.inaam.qarz.data.Person
import com.inaam.qarz.data.PersonSummary
import com.inaam.qarz.data.QarzDb
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.abs

class QarzViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = QarzDb.get(app).dao()

    val summaries: StateFlow<List<PersonSummary>> =
        combine(dao.people(), dao.allEntries()) { people, entries ->
            val byPerson = entries.groupBy { it.personId }
            people
                .map { p -> PersonSummary(p, byPerson[p.id].orEmpty().sumOf { it.signed() }) }
                .sortedByDescending { abs(it.balance) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun person(id: Long): Flow<Person?> = dao.person(id)
    fun entries(id: Long): Flow<List<Entry>> = dao.entriesFor(id)

    fun addPerson(name: String, phone: String, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val id = dao.insertPerson(Person(name = name.trim(), phone = phone.trim()))
            onDone(id)
        }
    }

    fun addEntry(personId: Long, amount: Double, type: EntryType, note: String) {
        viewModelScope.launch {
            dao.insertEntry(
                Entry(personId = personId, amount = amount, type = type.name, note = note.trim())
            )
        }
    }

    fun deleteEntry(entry: Entry) {
        viewModelScope.launch { dao.deleteEntry(entry) }
    }

    fun deletePerson(id: Long) {
        viewModelScope.launch { dao.deletePerson(id) }
    }
}
